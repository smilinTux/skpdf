"""
SKPDF - PDF field extraction and auto-fill from JSON profiles.

Copyright (C) 2025 smilinTux
Licensed under GPL-3.0-or-later.
"""

__version__ = "0.1.0"
